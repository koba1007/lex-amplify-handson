'use strict';
const axios = require("axios");

module.exports.getWeather = async (event) => {
  const city = event.currentIntent.slots["City"];
  const url = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&units=metric&lang=ja&APPID=XXXXXXXXXXXXXXXXXXXXXXXXXXx";

  try {
    const response = await axios.get(url);
    const data = response.data;

    const answer = "気温は " + data.main.temp + "C 湿度は " + data.main.humidity + "% 天気は " + data.weather[0].description + " の予報です。";
    
    return {
      "sessionAttributes": {},
      "dialogAction": {
        "type": "Close",
        "fulfillmentState": "Fulfilled",
        "message": {
          "contentType": "PlainText",
          "content": answer
        }
      }
    }
  } catch (error) {
    console.log(error);
  }
};